<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rate our Workshop!</title>
    <link href="css/styles.css" rel="stylesheet">
    <script>
      function validate(form) {
        var valid = true
        var error = ""

        for (var i = 0; i < form.length-1; i++) {
          if (form[i].value.trim() == "") {
            error = "You must provide your " + form[i].name + "."
            valid = false
            break;
          }
        }

        if (valid) {
          return true
        } else {
          alert(error)
          return false
        }
      }
    </script>
  </head>
  <body>
    <div class="mt-3 centered">
    <h1>Rate Botterill & Bartlett's 1-Day Business Workshop!</h1>
    

    <br>We're all ears! How was it for you?<br>
    Rate us from 1 (awful) to 5 (awesome).
    <br><br>
    </div>

    <?php
      $name = $email = $rating = "";
      if (!empty($_GET['name'])) {
        $name = $_GET['name'];
      }
      if (!empty($_GET['email'])) {
        $email = $_GET['email'];
      }
      if (!empty($_GET['rating'])) {
        $rating = $_GET['rating'];
      }
      $image = "";
    ?>

    <form action="index.php" onSubmit="return validate(this)">

      <div class="row"><div class="mb-3 col-sm-12">
      <div class="row"><div class="col-6 mx-sm-auto">
        <label for="inpName" class="form-label">Full Name</label>
        <input type="text" class="form-control centered" id="inpName" name="name">
      </div></div></div></div>

      <div class="row"><div class="mb-3 col-sm-12">
      <div class="row"><div class="col-6 mx-sm-auto">
        <label for="inpEmail" class="form-label">Email address</label>
        <input type="email" class="form-control" id="inpEmail" name="email">
      </div></div></div></div>

      <div class="row"><div class="mb-3 col-sm-12">
      <div class="row"><div class="col-6 mx-sm-auto">
        <label for="inpRating" class="form-label">Rating</label>
        <select class="form-control" id="inpRating" name="rating">
          <option>1 (Awful)</option>
          <option>2 (Bad)</option>
          <option>3 (Average)</option>
          <option>4 (Good)</option>
          <option>5 (Awesome)</option>
        </select>
      </div></div></div></div>

      <div class="row"><div class="mb-3 col-sm-12">
      <div class="row"><div class="col-6 mx-sm-auto centered">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div></div></div></div>
      
    </form>
    <br>

    <div class="centered">
    <?php
      if ($name != "") {
        echo "<h2>Thanks for your feedback, ";
        echo $name;
        echo ".</h2><br>";
      }
      switch ($rating) {
        case "1 (Awful)":
          $image = "img/awful.gif";
          break;
        case "2 (Bad)":
          $image = "img/bad.gif";
          break;
        case "3 (Average)":
          $image = "img/average.gif";
          break;
        case "4 (Good)":
          $image = "img/good.gif";
          break;
        case "5 (Awesome)":
          $image = "img/awesome.gif";
          break;
      }
    ?>
    <img src="<?php echo $image;?>" class="img-fluid">
    </div>
    
  </body>
</html>